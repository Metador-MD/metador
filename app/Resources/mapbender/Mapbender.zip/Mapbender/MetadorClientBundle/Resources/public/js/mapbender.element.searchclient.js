(function($){

    $.widget("mapbender.mbSearchClient", {
        options: {
            lang: "de",
            title: "MeTaDor",
            type: 'dialog',
            target: null,
            width: Math.round(parseInt($('body').css("width")) * 0.9),
            height: Math.round(parseInt($('body').css("height")) * 0.85),
            url: null
        },
        calledToken: null,
        _create: function(){
            var self = this;
            if(!Mapbender.checkTarget("mbSearchClient", this.options.target)){
                return;
            }
            Mapbender.elementRegistry.onElementReady(this.options.target, $.proxy(self._setup, self));
        },
        _setup: function(){
            $(window).on("message", $.proxy(this.searchCallback, this));
            var lang = $('html').attr('lang');
            if(typeof lang !== 'undefined' && lang !== '')
                this.options.lang = lang;

            if(this.options.type === 'element'){
                var self = this;
                var wmsloader = $('#' + this.options.target).data('mapbenderMbWmsloader'),
                    extent = $('#' + wmsloader.options.target).data('mapbenderMbMap').getModel().mapMaxExtent.extent;
                this.calledToken = Mapbender.UUID();
                var url = this.options.metadorUrl + '?' + $.param({
                    lang: self.options.lang,
                    east: extent.left,
                    west: extent.right,
                    north: extent.top,
                    south: extent.bottom,
                    token: this.calledToken,
                    mb: 'true'
                });
                this.element.removeClass('hidden').html('<iframe width="100%" height="100%" src="' + url + '"></iframe>');
            }
            this._trigger('ready');
            this._ready();
        },
        defaultAction: function(callback){
            if(this.options.type === 'dialog'){
                this.open(callback);
            }
        },
        open: function(callback){
            if(this.options.type === 'dialog'){
                this.callback = callback ? callback : null;
                this._openDialog();
            }
        },
        close: function(){
            if(this.options.type === 'dialog'){
                this._closeDialog();
                this.callback ? this.callback.call() : this.callback = null;
            }
        },
        searchCallback: function(event){
            var data = typeof event.data !== 'undefined' ? $.parseJSON(event.data) : $.parseJSON(event.originalEvent.data);
            if(data.token !== this.calledToken){
                return;
            }
            var wmsloader = $('#' + this.options.target).data('mapbenderMbWmsloader');
            var options = {
                'gcurl': data.load.wms,
                'type': 'url',
                'layers': {},
                'global': {
                    'mergeSource': false,
                    'splitLayers': wmsloader.options.splitLayers,
                    'options': {'treeOptions': {'selected': true}}
                }
            };
            var params = OpenLayers.Util.getParameters(options.gcurl);
            var request = null, service = null, sep = "";
            for(param in params){
                if(param.toUpperCase() === "REQUEST"){
                    request = params[param];
                }else if(param.toUpperCase() === "SERVICE"){
                    service = params[param];
                }
            }
            if(request === null){
                options.gcurl = OpenLayers.Util.urlAppend(options.gcurl, "request=getCapabilities");
            }
            if(service === null){
                options.gcurl = OpenLayers.Util.urlAppend(options.gcurl, "service=WMS");
            }
            wmsloader.loadWms(options);
        },
        _openDialog: function(url){
            var self = this;
            var wmsloader = $('#' + this.options.target).data('mapbenderMbWmsloader'),
                extent = $('#' + wmsloader.options.target).data('mapbenderMbMap').getModel().mapMaxExtent.extent;
            this.calledToken = Mapbender.UUID();
            var url = this.options.metadorUrl + '?' + $.param({
                lang: self.options.lang,
                east: extent.left,
                west: extent.right,
                north: extent.top,
                south: extent.bottom,
                token: this.calledToken,
                mb: 'true'
            });
            if(!this.popup || !this.popup.$element){
                this.element.show();
                this.popup = new Mapbender.Popup2({
                    title: self.element.attr('title'),
                    draggable: true,
                    modal: false,
                    closeButton: false,
                    closeOnESC: false,
                    content: [
                        '<iframe width="100%" height="' + parseInt(self.options.height - 140) + '" src="' + url + '"></iframe>'
                    ],
                    resizable: true,
                    width: self.options.width,
                    height: self.options.height,
                    buttons: {
                        'cancel': {
                            label: Mapbender.trans('mb.metadorclient.searchclient.dialog.btn.cancel'),
                            cssClass: 'button buttonCancel critical right',
                            callback: function(){
                                self.close();
                            }
                        }
                    }
                });
                this.popup.$element.on('close', function() {
                    self.close();
                });
                $('div.popupContent', this.popup.$element).css({'max-height': (self.options.height - 70) + 'px', 'height': (self.options.height - 130) + 'px'})
            }else{
                this.popup.open();
            }
        },
        _closeDialog: function(){
            if(this.popup){
                this.element.hide().appendTo($('body'));
                if(this.popup.$element)
                    this.popup.destroy();
                this.popup = null;
            }
        },
        /**
         *
         */
        ready: function(callback){
            if(this.readyState === true){
                callback();
            }else{
                this.readyCallbacks.push(callback);
            }
        },
        /**
         *
         */
        _ready: function(){
            for(callback in this.readyCallbacks){
                callback();
                delete(this.readyCallbacks[callback]);
            }
            this.readyState = true;
        },
        _destroy: $.noop
    });

})(jQuery);

