<?php
namespace Mapbender\MetadorClientBundle\Template;

use Mapbender\CoreBundle\Template\Fullscreen;

/**
 * Template Classic
 */
class Metador extends Fullscreen
{

    /**
     * @inheritdoc
     */
    public static function getTitle()
    {
        return 'MeTaDor Template (Fullscreen)';
    }

    /**
     * @inheritdoc
     */
    public static function listAssets()
    {
        $assets = Fullscreen::listAssets();
        return $assets;
    }

    /**
     * @inheritdoc
     */
    public function getLateAssets($type)
    {
        $assets = array(
            'css' => array("@MapbenderMetadorClientBundle/Resources/public/css/metador.css"),
            'js' => array(),
            'trans' => array()
        );
        return $assets[$type];
    }
}
