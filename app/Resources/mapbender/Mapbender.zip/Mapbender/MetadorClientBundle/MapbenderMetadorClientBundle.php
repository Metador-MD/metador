<?php

namespace Mapbender\MetadorClientBundle;

use Mapbender\CoreBundle\Component\MapbenderBundle;

class MapbenderMetadorClientBundle extends MapbenderBundle
{

    /**
     * @inheritdoc
     */
    public function getTemplates()
    {
        return array('Mapbender\MetadorClientBundle\Template\Metador');
    }
    
    /**
     * @inheritdoc
     */
    public function getElements()
    {
        return array(
            'Mapbender\MetadorClientBundle\Element\SearchClient',
            'Mapbender\MetadorClientBundle\Element\MetadorSearchClient'
        );
    }

}
