<?php

namespace Mapbender\MetadorClientBundle\Element\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

/**
 *
 * @author Paul Schmidt
 */
class MetadorSearchClientAdminType extends AbstractType
{

    /**
     * @inheritdoc
     */
    public function getName()
    {
        return 'searchclient';
    }

    /**
     * @inheritdoc
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'application' => null
        ));
    }

    /**
     * @inheritdoc
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add(
            'tooltip',
            'text',
            array('required' => false)
        )->add(
            'type',
            'choice',
            array(
                'required' => true,
                'choices' => array(
                    'dialog' => 'Dialog',
                    'element' => 'Element'
                )
            )
        )->add(
            'metadorUrl',
            'text',
            array('required' => true)
        )->add(
            'target',
            'target_element',
            array(
                'element_class' => 'Mapbender\\WmsBundle\\Element\\WmsLoader',
                'application' => $options['application'],
                'property_path' => '[target]',
                'required' => false
            )
        );
    }
}
