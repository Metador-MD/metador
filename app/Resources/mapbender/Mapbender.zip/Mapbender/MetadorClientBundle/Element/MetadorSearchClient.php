<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Mapbender\MetadorClientBundle\Element;

use Mapbender\CoreBundle\Component\Element;

/**
 *
 * @author Paul Schmidt
 */
class MetadorSearchClient extends Element
{
    /**
     * @inheritdoc
     */
    public static function getClassTitle()
    {
        return "mb.metadorclient.metador.searchclient.class.title";
    }

    /**
     * @inheritdoc
     */
    public static function getClassDescription()
    {
        return "mb.metadorclient.metador.searchclient.class.description";
    }

    /**
     * @inheritdoc
     */
    public static function getType()
    {
        return 'Mapbender\MetadorClientBundle\Element\Type\MetadorSearchClientAdminType';
    }


    /**
     * @inheritdoc
     */
    public static function getClassTags()
    {
        return array(
            'mb.metadorclient.searchclient.tag.search',
            'mb.metadorclient.searchclient.tag.metador',
            'mb.metadorclient.searchclient.tag.client',
            'mb.metadorclient.metador.searchclient.tag.search'
        );
    }

    /**
     * @inheritdoc
     */
    public function getAssets()
    {
        return array(
            'js'    => array('js/mapbender.element.searchclient.js'),
            'css'   => array(),
            'trans' => array('MapbenderMetadorClientBundle:Element:searchclient.json.twig')
        );
    }

    /**
     * @inheritdoc
     */
    public static function getDefaultConfiguration()
    {
        return array(
            'tooltip'    => 'call MeTaDor search',
            "type"       => null,
            'metadorUrl' => null,
            'target'     => null
        );
    }

    /**
     * @inheritdoc
     */
    public function getWidgetName()
    {
        return 'mapbender.mbSearchClient';
    }

    /**
     * @inheritdoc
     */
    public function render()
    {
        return $this->container->get('templating')
            ->render(
                'MapbenderMetadorClientBundle:Element:searchclient.html.twig',
                array(
                    'id' => $this->getId(),
                    'title' => $this->getTitle(),
                    'configuration' => $this->getConfiguration()
                )
            );
    }

    /**
     * @inheritdoc
     */
    public static function getFormTemplate()
    {
        return "MapbenderMetadorClientBundle:ElementAdmin:searchclient.html.twig";
    }
}
